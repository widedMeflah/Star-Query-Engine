package qengine.program;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.eclipse.rdf4j.query.algebra.Projection;
import org.eclipse.rdf4j.query.algebra.StatementPattern;
import org.eclipse.rdf4j.query.algebra.helpers.AbstractQueryModelVisitor;
import org.eclipse.rdf4j.query.algebra.helpers.StatementPatternCollector;
import org.eclipse.rdf4j.query.parser.ParsedQuery;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLParser;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.RDFParser;
import org.eclipse.rdf4j.rio.Rio;
import com.opencsv.CSVWriter;

public final class Main {

    static final String baseURI = null;
    public static String queryFile = "pdata/queries100K.queryset";
    public static String dataFile =  "pdata/data500k.nt";

    static String outputPath ="";
    static boolean useJena = true;
    static String warmPercentage = "";
    static boolean shuffle = false;
    
    // Create an instance of the Dictionnaire class
    static Dictionnaire dictionnaire = new Dictionnaire();
    static Triplet hexastore = new Triplet();
    static Hexastore hexastoreCollection = Hexastore.getInstance();

    static List<String[]> data = new ArrayList<String[]>();
    static int i = 1;

    /**
     * Méthode utilisée ici lors du parsing de requête sparql pour agir sur l'objet obtenu.
     */
   
    public static void main(String[] args) throws Exception {
    	
    	 CommandLineParser parser = new DefaultParser();
         Options options = new Options();

         options.addOption("queries", true, "Chemin vers le dossier de requêtes");
         options.addOption("data", true, "Chemin vers le fichier de données");
         options.addOption("output", true, "Chemin vers le dossier de sortie");
         options.addOption("jena", false, "Active la vérification Jena");
         options.addOption("warm", true, "Pourcentage d'échantillonnage pour chauffer le système");
         options.addOption("shuffle", false, "Permutation aléatoire des requêtes");

         try {
             CommandLine cmd = parser.parse(options, args);

             queryFile = cmd.getOptionValue("queries");
             dataFile = cmd.getOptionValue("data");
             outputPath = cmd.getOptionValue("output");
             useJena = cmd.hasOption("jena");
             warmPercentage = cmd.getOptionValue("warm");
             shuffle = cmd.hasOption("shuffle");

             System.out.println("queriesPath: " + queryFile);
             System.out.println("dataPath: " + dataFile);
             System.out.println("outputPath: " + outputPath);
             System.out.println("useJena: " + useJena);
             System.out.println("warmPercentage: " + warmPercentage);
             System.out.println("shuffle: " + shuffle);

         } catch (ParseException e) {
             System.err.println("Erreur lors de la lecture des arguments : " + e.getMessage());
         }
    	

    	long startTime = System.currentTimeMillis();
    	//Parser les donnees : creer le dictionnaire 
        parseData();
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;
        System.out.println("Temps de réponse Lecture data: " + responseTime + " millisecondes");

        
        // Affichage du contenu du Hexastore pour each permutation
        //afficherHexastore();
        startTime = System.currentTimeMillis();
        
        //Parser les requetes 
        parseQueries();
        
        endTime = System.currentTimeMillis();
        responseTime = endTime - startTime;
        System.out.println("Temps de réponse parseQueries(): " + responseTime + " millisecondes");
        
        
       //Evaluer les requetes
        QueryEvaluationJena.evaluateQueriesByJena();

        
       //Exporter le dictionnaire 
       dictionnaire.exporterEnCSVTrie(outputPath +"dictionnaire_trie.csv");
       
       //Exporter les Resultats de l'evaluation
       exportToCSV(data, outputPath + "/results.csv");
       
       
       doubleQueriesCalcule();
   	   System.out.println("queriesOcc = " + queriesOcc);
    }
    
    public static void afficherHexastore() {
    	System.out.println("Contenu du Hexastore (SPO permutation):");
        
		hexastoreCollection.getSPO().afficherContenu();

        System.out.println("Contenu du Hexastore (SOP permutation):");
        hexastoreCollection.getSOP().afficherContenu();

        System.out.println("Contenu du Hexastore (PSO permutation):");
        hexastoreCollection.getPSO().afficherContenu();

        System.out.println("Contenu du Hexastore (POS permutation):");
        hexastoreCollection.getPOS().afficherContenu();

        System.out.println("Contenu du Hexastore (OSP permutation):");
        hexastoreCollection.getOSP().afficherContenu();

        System.out.println("Contenu du Hexastore (OPS permutation):");
        hexastoreCollection.getOPS().afficherContenu();
    
    }


    private static void parseData() throws FileNotFoundException, IOException {
        try (Reader dataReader = new FileReader(dataFile)) {
            // On va parser des données au format ntriples
            RDFParser rdfParser = Rio.createParser(RDFFormat.NTRIPLES);

            // On utilise notre implémentation de handler
            MainRDFHandler rdfHandler = new MainRDFHandler(dictionnaire,hexastoreCollection);
            rdfParser.setRDFHandler(rdfHandler);

            // Parsing et traitement de chaque triple par le handler
            rdfParser.parse(dataReader, baseURI);
        }
    }
 
    private static void parseQueries() throws FileNotFoundException, IOException {

		/*
		 * On utilise un stream pour lire les lignes une par une, sans avoir à toutes les stocker
		 * entièrement dans une collection.
		 */
		try (Stream<String> lineStream = Files.lines(Paths.get(queryFile))) {
			SPARQLParser sparqlParser = new SPARQLParser();
			Iterator<String> lineIterator = lineStream.iterator();
			StringBuilder queryString = new StringBuilder();
			int cpt = 0;
			while (lineIterator.hasNext())
			/*
			 * On stocke plusieurs lignes jusqu'à ce que l'une d'entre elles se termine par un '}'
			 * On considère alors que c'est la fin d'une requête
			 */
			{
				String line = lineIterator.next();
				queryString.append(line);

				if (line.trim().endsWith("}")) {
					ParsedQuery query = sparqlParser.parseQuery(queryString.toString(), baseURI);
					boolean result = processAQuery(query, queryString.toString()); // Traitement de la requête, à adapter/réécrire pour votre programme
					if(result) cpt++;
					queryString.setLength(0); // Reset le buffer de la requête en chaine vide
					
				}
				
			}
			System.out.println("nb requetes = " + i);
			System.out.println("Nb Queries has results = " + (cpt-1));
			System.out.println("Nb results for all queries = " + cptNbResponses);
			System.out.println("queries Conditions = " + queriesNbConditions);
		
			
			
		}
	}
    static ArrayList<Integer> queriesOcc = new ArrayList<>();
    static void doubleQueriesCalcule() {
    	for (int i = 0; i < data.size(); i++) {
    		int occ = 0;
    		if(!data.get(i)[4].equals("/")) {
    			for (int j = i; j < data.size(); j++) {
        			if(data.get(i)[1].equals(data.get(j)[1])){
        				occ++;
        				data.get(j)[4] = "/";
        			}
        		}
    			data.get(i)[4] = ""+occ;
    		}
		}
    	
    	for (int i = 0; i < data.size(); i++) {
    		if(!data.get(i)[4].equals("/")) {
    			//System.out.println(" data.get(i)[4] = " + data.get(i)[4]);
    			int occ = Integer.parseInt(data.get(i)[4]);
    			//System.out.println(" occ = " + occ);
    			
    			if(queriesOcc.size()<=occ) {
    				for (int j = queriesOcc.size(); j <= occ; j++) {
    					queriesOcc.add(0);
    					
    				}
    				
    			}
    			queriesOcc.set(occ, queriesOcc.get(occ)+1);
    		}
		}
    	
		
    }
    
	// ========================================================================

	/**
	 * Méthode utilisée ici lors du parsing de requête sparql pour agir sur l'objet obtenu.
	 */

    static ArrayList<Integer> queriesNbConditions = new ArrayList<Integer>();
    
	public static boolean processAQuery(ParsedQuery query, String queryString) {
		List<StatementPattern> patterns = StatementPatternCollector.process(query.getTupleExpr());
		
		//System.out.println("---------------------------------------------- Une Requete "  + i + " ----------------------------------------------");
		List<Integer> resultList = null;
		int nbCondition = 0;
		for (StatementPattern statementPattern : patterns) {
			nbCondition++;
			//System.out.println("        ----  Condition  ------------");
			String O = statementPattern.getObjectVar().getValue().toString();
			String P = statementPattern.getPredicateVar().getValue().toString();
			
			//System.out.println("              o         = " +O.replace("\"", ""));
			//System.out.println("              p         = " +P .replace("\"", ""));
			int oChiffre = dictionnaire.chiffrerParametreQuery(O.replace("\"", ""));
			int pChiffre = dictionnaire.chiffrerParametreQuery(P);
			//System.out.println("              o codé =  " + oChiffre);
			//System.out.println("              p decodé =  " + pChiffre);
			
			 List<Integer> sChiffre = hexastoreCollection.find(pChiffre, oChiffre );
		//	System.out.println("              reponse indiv  =  " + sChiffre);

			if(resultList == null)
				 resultList = new  ArrayList<Integer>(sChiffre);
			else {
				resultList.retainAll(sChiffre);
			}
		//	System.out.println("        ---- END Condition  ------------");
		}
		if(queriesNbConditions.size()<=nbCondition) {
			for (int i = queriesNbConditions.size(); i <= nbCondition; i++) 
				queriesNbConditions.add(0);
		}
		queriesNbConditions.set(nbCondition, queriesNbConditions.get(nbCondition)+1);
		
		//System.out.println("la reponse coder est  =  " + resultList);
		List<String> result = decoderResult(resultList);
	//	System.out.println("la reponse decoder est  =  " + result);
		
		data.add(new String[]{i+"", queryString, result.toString(), "",""});
		
		//System.out.println("----------------------------------------------END requete----------------------------------------------");
		//System.out.println("                 ");
		//System.out.println("                 ");
		

		// Utilisation d'une classe anonyme
		query.getTupleExpr().visit(new AbstractQueryModelVisitor<RuntimeException>() {

			public void meet(Projection projection) {
				//System.out.println(projection.getProjectionElemList().getElements());
			}
		});
		i++;
		cptNbResponses += result.size();
		return result.size()>0 ? true :false;
	}
	static int cptNbResponses = 0;
	static List<String> decoderResult(List<Integer> sChiffre) {
		List<String> result = new ArrayList<>();
		for (Integer elt : sChiffre) {
			result.add(dictionnaire.dechiffrer(elt));
		}
		return result;
	}
	public static void exportToCSV(List<String[]> data, String filePath) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            // Écriture de l'en-tête du fichier CSV
            String[] header = {"Num", "Requete", "Notre Resultat", "Result Jena"};
            writer.writeNext(header);

            // Écriture des données
            writer.writeAll(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}