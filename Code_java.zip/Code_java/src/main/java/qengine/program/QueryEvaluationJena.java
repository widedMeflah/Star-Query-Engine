package qengine.program;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.jena.query.Query;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.query.*;

public class QueryEvaluationJena {

    static final String baseURI = null;
    static final String workingDir = "data/";
    public static String queryFile = "pdata/queries100K.queryset";
    public static String dataFile =  "pdata/data500k.nt";
    
	
	public static void evaluateQueriesByJena() {
		 // Chargement des données RDF depuis le fichier
        Model model = ModelFactory.createDefaultModel();
        try (InputStream in = new FileInputStream(Main.dataFile)) {
            model.read(in, null, "N-TRIPLE");  // Format N-Triples
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Lecture des requêtes depuis le fichier
        String[] queries = readQueriesFromFile(Main.queryFile);

        int i = 0;
        int cpt = 0;
        ArrayList<String> resultsList;
        
        long startTime = System.currentTimeMillis();
        
        
        // Évaluation des requêtes
        for (String queryString : queries) {
        	boolean hasResult = false;
        	//System.out.println("--------------------------------------------  REQUETE " + i+ "-------------------------------------");
            Query query = QueryFactory.create(queryString);
            //System.out.println("query = "+ query.toString());
         
            try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
                ResultSet results = qexec.execSelect();
                resultsList = new ArrayList<>();
                // Traitement des résultats
                while (results.hasNext()) {
                    QuerySolution soln = results.nextSolution();
                    // Accédez aux variables du résultat
                    RDFNode v0 = soln.get("v0");
                    resultsList.add(v0.toString());
                   // System.out.println("Résultat : " + v0.toString());
                    if(!hasResult) {
                    	hasResult = true;
                    	cpt ++;
                    }
                }
            }
            Main.data.get(i)[3] = resultsList.toString();
            //System.out.println("-----------------------------------------------------------------------------------------------");
            i++;
           // System.out.println("cpt = " + cpt);
        }
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;
        System.out.println("Temps de réponse QueryEvaluationJena() : " + responseTime + " millisecondes");

		
	}

    // Fonction pour lire les requêtes depuis un fichier
    private static String[] readQueriesFromFile(String filePath) {
    	  List<String> queryList = new ArrayList<String>();

          try {
              List<String> lines = Files.lines(Paths.get(filePath)).collect(Collectors.toList());

              StringBuilder currentQuery = new StringBuilder();
              for (String line : lines) {
                  currentQuery.append(line);

                  if (line.trim().endsWith("}")) {
                      queryList.add(currentQuery.toString());
                      currentQuery.setLength(0); // Reset le buffer de la requête en chaine vide
                  }
              }
          } catch (Exception e) {
              e.printStackTrace();
          }

          return queryList.toArray(new String[0]);
     }
    
}
