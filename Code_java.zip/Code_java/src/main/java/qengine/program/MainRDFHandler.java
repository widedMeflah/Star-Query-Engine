package qengine.program;

import org.eclipse.rdf4j.model.Statement;
import org.eclipse.rdf4j.rio.helpers.AbstractRDFHandler;

public final class MainRDFHandler extends AbstractRDFHandler {
    private Dictionnaire dictionnaire;
    private Hexastore hexastoreCollection;

    public MainRDFHandler(Dictionnaire dictionnaire, Hexastore hexastoreCollection) {
        this.dictionnaire = dictionnaire;
        this.hexastoreCollection = hexastoreCollection;
    }

    @Override
    public void handleStatement(Statement st) {
        String sujet = st.getSubject().stringValue();
        String predicat = st.getPredicate().stringValue();
        String objet = st.getObject().stringValue();
        //System.out.println("object = " + objet);
        // Ajout du triplet RDF au Hexastore en utilisant le Dictionnaire pour le chiffrement
        int indexSujet = dictionnaire.chiffrerSujet(sujet);
        int indexPredicat = dictionnaire.chiffrerPredicat(predicat);
        int indexObjet = dictionnaire.chiffrerObjet(objet);
        
        hexastoreCollection.hexastore(indexSujet, indexPredicat, indexObjet);

        // Affichage du triplet RDF avec les parties chiffrées et déchiffrées
       /// System.out.println("Triplet RDF codé : (" + indexSujet + ", " + indexPredicat + ", " + indexObjet + ")");
        //System.out.println("Triplet RDF décodé : (" + dictionnaire.dechiffrerSujet(indexSujet) + ", "
       ///         + dictionnaire.dechiffrerPredicat(indexPredicat) + ", " + dictionnaire.dechiffrerObjet(indexObjet) + ")");
        
    	
    }
}
