package qengine.program;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.List;

/*
 * Stores data (from a Dictionary) in a triple store format.
 *
 * The structure is three levels deep, we have the root, which can have multiple internal children, which can have multiple leaves.
 * In a triplet, the first element would be the root node, the second the internal node, and the third would be the leaf node
 * */

public final class Triplet {
	
    private final Map<Integer, Map<Integer, HashSet<Integer>>> tripletsIndex;
    
    public Triplet() {
        this.tripletsIndex = new HashMap<>();
    }

    public void insertTriplet(int root, int internal, int leaf) {

        //If the root of the triplet we want to add is not already in the index, we add it, along with an empty internal child.
        tripletsIndex.computeIfAbsent(root, k -> new HashMap<>());

        //If the internal node we want to add is not already a child of the root, we add it, along with an empty list of leaves
        tripletsIndex.get(root).computeIfAbsent(internal, k -> new HashSet<>());

        //If the leaf we want to add is not a child of the internal node, we add it
        tripletsIndex.get(root).get(internal).add(leaf);

        //If the triplet is already in the index, nothing happens
    }



   
    public void afficherContenu() {
        for (Map.Entry<Integer, Map<Integer, HashSet<Integer>>> entry1 : tripletsIndex.entrySet()) {
            int root = entry1.getKey();
            Map<Integer, HashSet<Integer>> internalMap = entry1.getValue();
            for (Map.Entry<Integer, HashSet<Integer>> entry2 : internalMap.entrySet()) {
                int internal = entry2.getKey();
                HashSet<Integer> leaves = entry2.getValue();
                for (int leaf : leaves) {
                    System.out.println("[" + root + ", " + internal + ", " + leaf + "]");
                }
            }
        }
    }
    public List<Integer> get(int par1, int par2) {
    	 List<Integer> list = new ArrayList<>();
    	 if(tripletsIndex.containsKey(par1))
    		 if(tripletsIndex.get(par1).containsKey(par2))
    			 list = new ArrayList<>(tripletsIndex.get(par1).get(par2));
    	return list;
    }
}
