package qengine.program;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Dictionnaire {

	

    private TreeMap<Integer, String> dechiffrementMap; // Pour déchiffrer les données RDF (Integer -> String)
    private TreeMap<String, Integer> chiffrementMap; // 
    
    public Dictionnaire() {
    	   
        dechiffrementMap = new TreeMap<>();
        chiffrementMap = new TreeMap<>();
    }

    // Méthode pour chiffrer une donnée RDF (String -> Integer)
    public int chiffrer(String donnee) {
        if (!chiffrementMap.containsKey(donnee)) {
            int nouvelIndex = chiffrementMap.size(); // Nouvel index unique pour la donnée
            chiffrementMap.put(donnee, nouvelIndex);
            dechiffrementMap.put(nouvelIndex, donnee);
        }
        return chiffrementMap.get(donnee);
    }
    // Méthode pour chiffrer une donnée RDF (String -> Integer)
    public int chiffrerParametreQuery(String parametre) {
        if (chiffrementMap.containsKey(parametre)) {
        	return chiffrementMap.get(parametre);
        }
        return -1;
    }

    // Méthode pour déchiffrer une donnée RDF (Integer -> String)
    public String dechiffrer(int index) {
        return dechiffrementMap.get(index);
    }

    // Méthode pour vérifier si une donnée est déjà chiffrée
    public boolean estChiffre(String donnee) {
        return chiffrementMap.containsKey(donnee);
    }

    // Méthode pour vérifier si un index a une correspondance déchiffrée
    public boolean aCorrespondance(int index) {
        return dechiffrementMap.containsKey(index);
    }

    // Méthode pour chiffrer le sujet d'un triplet RDF
    public int chiffrerSujet(String sujet) {
        return chiffrer(sujet);
    }

    // Méthode pour déchiffrer le sujet d'un triplet RDF
    public String dechiffrerSujet(int index) {
        return dechiffrer(index);
    }

    // Méthode pour chiffrer le prédicat d'un triplet RDF
    public int chiffrerPredicat(String predicat) {
        return chiffrer(predicat);
    }

    // Méthode pour déchiffrer le prédicat d'un triplet RDF
    public String dechiffrerPredicat(int index) {
        return dechiffrer(index);
    }

    // Méthode pour chiffrer l'objet d'un triplet RDF
    public int chiffrerObjet(String objet) {
        return chiffrer(objet);
    }

    // Méthode pour déchiffrer l'objet d'un triplet RDF
    public String dechiffrerObjet(int index) {
        return dechiffrer(index);
    }

    // Classe interne représentant chaque ligne du CSV avec index et donnée
    private static class Ligne {
        int index;
        String donnee;

        Ligne(int index, String donnee) {
            this.index = index;
            this.donnee = donnee;
        }
    }

    // Méthode pour trier le dictionnaire en fonction de l'index
    public List<Ligne> trierParIndex() {
        List<Ligne> lignesTriees = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : chiffrementMap.entrySet()) {
            String donnee = entry.getKey();
            int index = entry.getValue();

            // Ajouter la ligne à la liste des lignes triées
            lignesTriees.add(new Ligne(index, donnee));
        }
        
        // Utiliser un comparateur pour trier les lignes en fonction de l'index
        lignesTriees.sort(Comparator.comparingInt(ligne -> ligne.index));

        return lignesTriees;
    }

    // Méthode pour exporter les données triées dans un fichier CSV
    public void exporterEnCSVTrie(String nomFichier){
    	try {
		 List<Ligne> lignesTriees = trierParIndex();
	        try (FileWriter writer = new FileWriter(nomFichier)) {
	            for (Ligne ligne : lignesTriees) {
	                writer.append(ligne.index + "," + ligne.donnee + "\n");
	            }
	            writer.flush();
	        }
            System.out.println("Le dictionnaire trié a été exporté dans le fichier dictionnaire_trie.csv");
        } catch (IOException e) {
            System.err.println("Erreur lors de l'exportation du dictionnaire trié : " + e.getMessage());
        }
       
    }
}