package qengine.program;

import java.util.List;

/*
 * Stores six indexes to implement the hexastore approach
 * Each index corresponds to a different permutation of Subjet, Predicate, and Object
 * */
public class Hexastore {

    private static Hexastore indexCollection_instance = null;
    Triplet SPO = new Triplet();
    Triplet SOP = new Triplet();
    Triplet PSO = new Triplet();
    Triplet POS = new Triplet();
    Triplet OSP = new Triplet();
    Triplet OPS = new Triplet();

    Hexastore() {}

    public static Hexastore getInstance() {
        if (indexCollection_instance == null) {
            indexCollection_instance = new Hexastore();
        }
        return indexCollection_instance;
    }
    //POS.insertTriplet(predicate, object, subject);
    public  List<Integer> find(int p, int o) {
    	return POS.get( p, o);
    
    }

    //Adds a record to the index, in the right order for each TripleStore
    public void hexastore(int subject, int predicate, int object) {
        // Ajout du triplet dans chaque instance de Hexastore avec la permutation appropriée
        SPO.insertTriplet(subject, predicate, object);
        SOP.insertTriplet(subject, object, predicate);
        PSO.insertTriplet(predicate, subject, object);
        POS.insertTriplet(predicate, object, subject);
        OSP.insertTriplet(object, subject, predicate);
        OPS.insertTriplet(object, predicate, subject);
    }

    public Triplet getSPO() {
        return SPO;
    }

    public Triplet getSOP() {
        return SOP;
    }

    public Triplet getPSO() {
        return PSO;
    }

    public Triplet getPOS() {
        return POS;
    }

    public Triplet getOSP() {
        return OSP;
    }

    public Triplet getOPS() {
        return OPS;
    }
   
    
}